Installing instructions.
Easy way:
1) Clone the repository ( https://github.com/jimfil/SuperSnail )
2) Build the project using cmake
3) Run the .sln in the build folder

Source files:
1) Open an old lab folder and delete "common","lab XX" folders, and CMakeLists.txt file.
2) Extract the everything inside the lab folder 
3) Build the project like in every lab 
After step 3 the folder should look like:

build
common
ergasia
external
...
....
..
CMakeLists.txt
...
